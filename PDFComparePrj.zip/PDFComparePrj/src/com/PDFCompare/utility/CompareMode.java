package com.PDFCompare.utility;

public enum CompareMode {
	TEXT_MODE,
	VISUAL_MODE
}
