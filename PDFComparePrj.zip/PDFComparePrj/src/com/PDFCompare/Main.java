package com.PDFCompare;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.PDFCompare.utility.CompareMode;
import com.PDFCompare.utility.PDFUtil;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public final class Main {
public static Connection connection =null;
static PDFUtil pdfutil = new PDFUtil();
	public static void main(String[] args) throws IOException {

		
			
			pdfCompare();

	
	}
	private static void pdfCompare() throws IOException{
		Fillo fillo=new Fillo();
		try {
			 ExtentReports extent;
			 ExtentTest logger = null;
			 String time = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			 extent = new ExtentReports (System.getProperty("user.dir") +"/Results/Reports_"+time+"/Report.html", true);
			 //extent.addSystemInfo("Environment","Environment Name")
			 extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
			 
			 connection=fillo.getConnection(System.getProperty("user.dir")+"\\Config.xlsx");
			 String strQuery="Select * from Config";
			 Recordset recordset=connection.executeQuery(strQuery);
			
			 while(recordset.next()){
				String serialNo = recordset.getField("S.No");
				String ActualFile =recordset.getField("ActualFile");
				 String ExpectedFile =recordset.getField("ExpectedFile");
				 String Mode =recordset.getField("Mode");
				 System.out.println(serialNo);
				 System.out.println(ActualFile);
				 System.out.println(ExpectedFile);
				 CompareMode mode = null;
					if (Mode.toLowerCase().contains("text")) {
						mode = CompareMode.TEXT_MODE;
					} else if (Mode.toLowerCase().contains("image")) {

						mode = CompareMode.VISUAL_MODE;
					}

					pdfutil.setCompareMode(mode);
					String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
					String currentDir = System.getProperty("user.dir");
					System.out.println(currentDir);
					String fileName = new File(ActualFile).getName().replace(".", "_");
					 logger = extent.startTest("Compare File "+fileName);
					pdfutil.highlightPdfDifference(true);
					String FolderPath = currentDir + "/Results/Reports_"+time+"/" + fileName+"_"+timeStamp;
					File directory = new File(FolderPath);

					 
					if (directory.exists()) {
						pdfutil.setImageDestinationPath(FolderPath);
					} else {
						directory.mkdir();
						pdfutil.setImageDestinationPath(FolderPath);
					}

				boolean test = pdfutil.compare(ActualFile, ExpectedFile);
				if(test){
					logger.log(LogStatus.PASS, "File Compared and there are no differences");
					File[] Files = directory.listFiles();
					int len =Files.length ;
					for(int i =0;i<len;i++){
					String FilePath =Files[i].getAbsolutePath();
					logger.log(LogStatus.INFO," Differnece : <a href='"+FilePath+"'>LINK</a>");
				
					}}
				else{
					logger.log(LogStatus.FAIL, "File Compared and there are  differences");
					File[] Files = directory.listFiles();
					int len =Files.length ;
					for(int i =0;i<len;i++){
					String FilePath =Files[i].getAbsolutePath();
					logger.log(LogStatus.INFO," Differnece : <a href='"+FilePath+"'>LINK</a>");	}
				}
				extent.endTest(logger);
				 }
			 
			 
			 extent.flush();
                  extent.close();
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
